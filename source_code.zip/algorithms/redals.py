import numpy as np
import random
import copy
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor


class REDALS:

    def __init__(self, problem_func, dim, pop_size, max_iter,
                 num_pdf=3, num_cut_pdf=0.1, variables=None, direction="MAX", problem_repair=False, seed=None, f_factor=2,
                 type="redals"):
        self.problem_func = problem_func
        self.problem_repair = problem_repair
        self.num_of_variables = dim
        self.num_of_individuals = pop_size
        self.max_iter = max_iter
        self.num_pdf = num_pdf
        self.num_cut_pdf = num_cut_pdf
        self.variables = variables if variables is not None else [0,1]
        self.direction = direction
        self.surrogate_model = RandomForestRegressor(n_estimators=100)
        self.X_train = []
        self.y_train = []
        self.population = []
        self.elite_set = []
        self.f_factor = f_factor
        self.convergence_array = []
        self.best_history = []  # Best value at each iteration
        self.global_best = None  # Overall best individual
        self.type = type
        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)
        self.init_pop_features = (np.random.rand(self.num_of_individuals, self.num_of_variables) >= 0.5).astype(int)


    def create_initial_population(self):
        pop = []
        for k in range(self.num_of_individuals):
            features = self.init_pop_features[k]
            fitness = self.problem_func(features)
            pop.append({"features": features, "fitness": fitness, "p_selection": 0, 'prob': [[0.5,0.5] for _ in range(self.num_of_variables)]})
        return pop

    def update_probability_elite(self, population, gen):
        reverse_sort = True if self.direction == "MAX" else False
        population.sort(key=lambda ind: ind["fitness"], reverse=reverse_sort)
        self.elite_set = population[:self.num_pdf]


        for k in range(1,len(self.elite_set)+1): # Note by Artur: shouldn't k start from 1? Otherwise the sum of all probabilities will be > 1.0
            # Eq. (1): selection probability
            self.elite_set[k-1]['p_selection'] = ((self.num_pdf - k) + 1) / (self.num_pdf * (self.num_pdf + 1) / 2)

            decay_factor = 1 - ((gen - 1) / self.max_iter)  # (1 - (t - 1)/N)
            vec_probs = []
            for i in range(self.num_of_variables):
                prev_prob = np.array(self.elite_set[k-1]['prob'][i])
                elite_val = self.elite_set[k-1]['features'][i]
                index = self.variables.index(elite_val)
                # Eq. (2): apply decay
                updated = prev_prob * decay_factor
                updated[index] = updated[index] + (gen-1)/self.max_iter
                # Normalize to ensure probabilities sum to 1
                # Note by Artur: after applying the decay factor, you must increase the probability of the value that was selected for elite k in order to introduce a bias towards this value
                #if updated.sum() > 0:
                    #updated /= updated.sum()
                #else:
                    #updated[:] = 1.0 / len(updated)

                vec_probs.append(copy.deepcopy(updated.tolist()))

            self.elite_set[k-1]['prob'] = vec_probs


    def update_probabilities_if_duplicity(self, population):
        reverse_sort = True if self.direction == "MAX" else False
        population.sort(key=lambda ind: ind["fitness"], reverse=reverse_sort)
        #self.elite_set = population[:self.num_pdf]
        self.update_elite()

        for k in range(len(self.elite_set)):
            new_prob = []
            for i in range(len(self.variables)):
                prev_prob = np.array(self.elite_set[k]['prob'][i], dtype=float)
                max_p = np.max(prev_prob)
                updated = 0.9 * prev_prob + 0.1 * max_p

                # (3) Normalize to [0,1] (sum to 1)
                if updated.sum() > 0:
                    updated /= updated.sum()
                else:
                    updated[:] = 1.0 / len(updated)

                new_prob.append(copy.deepcopy(updated.tolist()))

            self.elite_set[k]['prob'] = new_prob


    def fit_surrogate(self, population):
        for ind in population:
            self.X_train.append(ind['features'])
            self.y_train.append(ind['fitness'])
        self.surrogate_model.fit(self.X_train, self.y_train)

    def local_search(self, orig):
        orig_y_pred = self.surrogate_model.predict(np.array(orig).reshape(1, -1))[0]
        candidates = []
        for i in range(self.num_of_variables):
            new_vec = {"features": orig, "fitness": 0}
            new_vec['features'][i] = 1 - orig[i] #shift the bit
            new_vec['fitness'] = self.surrogate_model.predict(np.array(new_vec["features"]).reshape(1, -1))[0]
            candidates.append(copy.deepcopy(new_vec))
        best = max(candidates, key=lambda c: c['fitness'])
        # Compare with original
        if best['fitness'] > orig_y_pred: #MAXIMIZATIOn
            return best['features']
        else:
            return orig
    
    def update_elite(self):
        reverse_sort = True if self.direction == "MAX" else False
        self.population.sort(key=lambda ind: ind["fitness"], reverse=reverse_sort)
        # Note by Artur: the elite set should be managed so that no solution is replaced by a worse one. If you replace all elites with the top individuals in the current population, you risk doing so
        current_best = self.population[:self.num_pdf]
        for k in range(len(current_best)):
            for j in range(len(self.elite_set)):
                if ((self.direction == "MAX" and current_best[k]["fitness"] > self.elite_set[j]["fitness"]) or
                (self.direction == "MIN" and current_best[k]["fitness"] < self.elite_set[j]["fitness"])):
                    self.elite_set[j] = current_best[k]


    def generate_new_population(self):
        # Extract probabilities from the elite set
        probs = np.array([elite['p_selection'] for elite in self.elite_set], dtype=float)
        new_pop = []
        new_pop_no_ls = []
        # Normalize to make sure they sum to 1
        if probs.sum() > 0:
            probs /= probs.sum()
        else:
            probs[:] = 1.0 / len(probs)
        for k in range(self.num_of_individuals * self.f_factor):
            # Randomly choose one elite index based on probabilities
            chosen_index = np.random.choice(len(self.elite_set), p=probs)
            parent = self.elite_set[chosen_index]
            features = []
            for i in range(self.num_of_variables):
                prob_var = parent['prob'][i]
                var_val = np.random.choice(self.variables, p=prob_var)
                features.append(var_val)
            # Note by Artur: I would evaluate the solutions and check their fitness first, then perform the local search. Since the LS uses a regression model, it is possible that it worsens some solutions
            fitness = self.surrogate_model.predict(np.array(features).reshape(1, -1))[0]
            #features = self.local_search(orig=features)
            new_pop_no_ls.append({"features": features, "fitness": fitness, "p_selection": parent['p_selection'], 'prob': parent['prob']})
        reverse_sort = True if self.direction == "MAX" else False
        new_pop_no_ls.sort(key=lambda ind: ind["fitness"], reverse=reverse_sort)
        new_pop_no_ls = new_pop_no_ls[:self.num_of_individuals]
        if self.type=="redals":
            for k in range(self.num_of_individuals):
                features = self.local_search(orig=new_pop_no_ls[k]['features'])
                fitness = self.problem_func(features)
                new_pop.append({"features": features, "fitness": fitness, "p_selection": new_pop_no_ls[k]['p_selection'], 'prob': new_pop_no_ls[k]['prob']})
        else:
            new_pop = new_pop_no_ls
            for k in range(self.num_of_individuals):
                fitness = self.problem_func(new_pop[k]['features'])
                new_pop[k]['fitness'] = self.problem_func(new_pop[k]['features'])
        return new_pop


    def optimize(self):
        self.population = self.create_initial_population()
        reverse_sort = True if self.direction == "MAX" else False
        self.population.sort(key=lambda ind: ind["fitness"], reverse=reverse_sort)
        self.elite_set = self.population[:self.num_pdf]
        self.global_best = copy.deepcopy(self.population[0])  # Initialize global best
        # Add this line to record initial population best
        self.best_history.append(self.global_best['fitness'])
        for gen in range(1,self.max_iter+1):
            self.update_elite()
            self.fit_surrogate(population=self.population)
            #print(f"Generation {gen+1}/{self.num_of_generations}")
            self.update_probability_elite(gen=gen, population=self.population)
            self.population = self.generate_new_population()

            reverse_sort = True if self.direction == "MAX" else False
            self.population.sort(key=lambda ind: ind["fitness"], reverse=reverse_sort)

            # Best of this iteration
            iteration_best = self.population[0]

            self.convergence_array.append(iteration_best["fitness"])

            # Update global best
            if ((self.direction == "MAX" and iteration_best["fitness"] > self.global_best["fitness"]) or
                (self.direction == "MIN" and iteration_best["fitness"] < self.global_best["fitness"])):
                self.global_best = copy.deepcopy(iteration_best)

            self.best_history.append(copy.deepcopy(self.global_best['fitness']))
            
            #print(f'Best so far {self.global_best["fitness"]}')
        #self.plot_convergence()
        return self.global_best['fitness'], self.best_history