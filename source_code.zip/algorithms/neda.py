import numpy as np
import random
import copy
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.exceptions import NotFittedError
from sklearn.utils.validation import check_is_fitted
from sklearn.metrics import mean_absolute_error
class IDLHC_BB_Hybrid:

    def __init__(self, problem_func, dim, pop_size, max_iter,
                 num_pdf=3, num_cut_pdf=0.1, variables=None, direction="MAX", 
                 problem_repair=False, seed=None, noise_dev=0.05):
        self.problem_func = problem_func
        self.problem_repair = problem_repair
        self.num_of_variables = dim
        self.num_of_individuals = pop_size
        self.max_iter = max_iter
        self.num_pdf = num_pdf if num_pdf < pop_size else pop_size
        self.num_cut_pdf = num_cut_pdf
        self.variables = variables if variables is not None else [0,1]
        self.direction = direction
        self.surrogate = RandomForestRegressor()
        self.population = []
        self.population_surrogate = []
        self.convergence_array = []
        self.dim = dim
        self.best_history = []  # Best value at each iteration
        self.global_best = None  # Overall best individual
        self.mae = 0
        self.var_count = []
        self.probs = []
        self.inverse_probs = []
        self.var_count_surrogate = []
        self.probs_surrogate = []
        self.delta = 0
        self.noise_dev = noise_dev
        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)
        self.init_pop_features = (np.random.rand(self.num_of_individuals, self.num_of_variables) >= 0.5).astype(int)

    def create_initial_population(self):
        pop = []
        for k in range(self.num_of_individuals):
            features = self.init_pop_features[k]
            fitness = self.problem_func(features)
            pop.append({"features": features, "fitness": fitness})
        return pop


    def variable_count(self, population):
        count_var = [[] for _ in range(self.num_of_variables)]
        best_features = []

        reverse_sort = True if self.direction == "MAX" else False
        population.sort(key=lambda ind: ind["fitness"], reverse=reverse_sort)

        best_features = [ind["features"] for ind in population[:self.num_pdf]]

        for best in best_features:
            for idx, var in enumerate(best):
                count_var[idx].append(var)

        self.var_count = count_var
    
    def add_noise(self):
        for k in range(self.num_of_variables):
            
            vec = np.array(self.probs[k])
            # Add small Gaussian noise
            noise = np.random.normal(0, self.noise_dev, size=vec.shape)  # mean=0, std=0.05
            noisy_vec = vec + noise

            s = noisy_vec.sum()
            if s == 0 or np.isnan(s):
                # Handle degenerate case — reinitialize to uniform distribution
                noisy_vec = np.ones_like(noisy_vec) / len(noisy_vec)
            else:
                noisy_vec /= s

            if np.isnan(noisy_vec).any():
                print(f"NaN detected at variable {k}: {noisy_vec}")

            self.probs[k] = list(noisy_vec)
    
    def update_probabilities(self):
        new_probabilities = [[] for _ in range(self.num_of_variables)]
        for i in range(self.num_of_variables):
            for candidate in self.variables:
                freq_norm = round(self.var_count[i].count(candidate) / self.num_pdf, 2)
                new_probabilities[i].append(freq_norm)
        self.probs = new_probabilities
        self.add_noise()

    def individual_cut_pdf(self, prob):
        np_prob = np.array(prob)
        mask = np_prob <= self.num_cut_pdf
        if not all(mask):
            if any(mask):
                np_prob[~mask] += np.sum(np_prob[mask]) / len(np_prob[~mask])
                np_prob[mask] = 0
        return list(np_prob)

    def adjust_cut_pdf(self):
        for i in range(len(self.probs)):
            self.probs[i] = self.individual_cut_pdf(self.probs[i])

    def generate_samples(self, probs, values, samples):
        sampled_values = []
        for prob, value in zip(probs, values):
            sampled_values += int(round(samples * prob)) * [value]

        if len(sampled_values) > 0:
            while len(sampled_values) != samples:
                unicos, counts = np.unique(sampled_values, return_counts=True)
                c = list(zip(unicos, counts))
                random.shuffle(c)
                unicos, counts = zip(*c)
                if len(sampled_values) > samples:
                    sampled_values.remove(unicos[np.argmax(counts)])
                elif len(sampled_values) < samples:
                    sampled_values += [unicos[np.argmin(counts)]]
            random.shuffle(sampled_values)
        return sampled_values

    def check_duplicity(self, sampled):
        sampled_clean = np.unique(sampled, axis=0)
        return sampled_clean

    def generate_new_population(self, correct_size, inverse=False):
        features_matrix = []
        for i in range(self.num_of_variables):
            #print(f'Probs[i] {self.probs[i]}')
            feature_column = self.generate_samples(self.probs[i], self.variables, correct_size)
            features_matrix.append(feature_column)

        features_matrix = np.array(features_matrix).T
        features_matrix = self.check_duplicity(features_matrix)

        new_population = []
        for feat in features_matrix:
            new_population.append({"features": list(feat),
                                   "fitness": self.problem_func(list(feat))})
        return new_population
    
    
    def update_best_candidate(self, candidates, best_candidate):
        for candidate in candidates:
            pred = self.surrogate.predict(np.array(candidate).reshape(1, -1))[0] - self.mae
            if ((self.direction == "MAX" and pred > self.global_best["fitness"]) or
                (self.direction == "MIN" and pred < self.global_best["fitness"])):
                if best_candidate is None:
                    best_candidate = {"features": candidate,
                                    "fitness": pred}
                elif ((self.direction == "MAX" and pred > best_candidate["fitness"]) or
                (self.direction == "MIN" and pred < best_candidate["fitness"])):
                    best_candidate = {"features": candidate,
                                    "fitness": pred}
        return best_candidate


    def optimize(self):
        self.population = self.create_initial_population()
        reverse_sort = True if self.direction == "MAX" else False
        self.population.sort(key=lambda ind: ind["fitness"], reverse=reverse_sort)
        self.global_best = copy.deepcopy(self.population[0])  # Initialize global best
        # Add this line to record initial population best
        self.best_history.append(self.global_best['fitness'])
        for gen in range(self.max_iter):
            #print(f"Generation {gen+1}/{self.num_of_generations}")
            self.variable_count(self.population)
            self.update_probabilities()
            self.population = self.generate_new_population(correct_size=self.num_of_individuals, inverse=True)

            reverse_sort = True if self.direction == "MAX" else False
            self.population.sort(key=lambda ind: ind["fitness"], reverse=reverse_sort)
            # Best of this iteration
            iteration_best = self.population[0]
            self.convergence_array.append(iteration_best["fitness"])

            # Update global best
            if ((self.direction == "MAX" and iteration_best["fitness"] > self.global_best["fitness"]) or
                (self.direction == "MIN" and iteration_best["fitness"] < self.global_best["fitness"])):
                self.global_best = copy.deepcopy(iteration_best)
            self.best_history.append(copy.deepcopy(self.global_best['fitness']))

        #self.plot_convergence()
        return self.global_best['fitness'], self.best_history
