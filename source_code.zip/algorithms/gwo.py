import numpy as np
import random
from utils.transfer_functions import TransferFunctions

class BinaryGWO:
    """
    Binary Grey Wolf Optimizer (BGWO)
    ---------------------------------
    Adapted for binary optimization using transfer functions.

    Parameters:
        problem_func : callable
            Objective function to optimize (receives a list of bits [0,1]).
        dim : int
            Number of variables (bits).
        pop_size : int, optional
            Number of wolves.
        max_iter : int, optional
            Maximum number of iterations.
        direction : {"MAX", "MIN"}, optional
            Optimization goal (default "MAX").
        seed : int, optional
            Random seed for reproducibility.
        transfer_function : str, optional
            Transfer function for binary mapping ("sigmoid", "tanh", "v3").
        X_min : float, optional
            Lower bound for continuous positions.
        X_max : float, optional
            Upper bound for continuous positions.
        a_max : float, optional
            Maximum value of the linear coefficient 'a'.
        a_min : float, optional
            Minimum value of the linear coefficient 'a' at the end.
    """
    def __init__(self, problem_func, dim, pop_size=30, max_iter=100, direction="MAX",
                 seed=None, transfer_function="sigmoid",
                 X_min=-10, X_max=10, a_max=2.0, a_min=0.0):
        
        self.problem_func = problem_func
        self.dim = dim
        self.pop_size = pop_size
        self.max_iter = max_iter
        self.direction = direction
        self.transfer_function = transfer_function
        self.X_min = X_min
        self.X_max = X_max
        self.a_max = a_max
        self.a_min = a_min

        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)


        # Initial binary population
        self.X_bin = (np.random.rand(pop_size, dim) >= 0.5).astype(int)
        self.fitness = np.array([self.problem_func(list(ind)) for ind in self.X_bin])
        # Continuous positions (used for transfer function mapping)
        self.X_cont = np.random.uniform(X_min, X_max, size=(pop_size, dim))

        # Leaders
        self.alpha = None
        self.beta = None
        self.delta = None
        self.alpha_score = -np.inf if direction == "MAX" else np.inf

        # Global best tracking
        self.best_solution = None
        self.best_value = -np.inf if direction == "MAX" else np.inf
        self.best_history = []

        # Initialize hierarchy
        self._update_hierarchy()
        self._update_global_best()

    def _binarize(self, cont_positions):
        """Transfer function mapping continuous positions to binary."""
        if self.transfer_function == "sigmoid":
            probs = TransferFunctions._sigmoid(x=cont_positions)
        elif self.transfer_function == "tanh":
            probs = TransferFunctions._tanh(x=cont_positions)
        elif self.transfer_function == "v3":
            probs = TransferFunctions._v3(x=cont_positions)
        rand_mat = np.random.rand(*probs.shape)
        return (rand_mat < probs).astype(int)

    def _update_hierarchy(self):
        """Update alpha, beta, delta wolves based on fitness."""
        sorted_idx = np.argsort(self.fitness) if self.direction == "MIN" else np.argsort(-self.fitness)
        self.alpha = self.X_cont[sorted_idx[0]].copy()
        self.beta  = self.X_cont[sorted_idx[1]].copy() if self.pop_size > 1 else self.alpha.copy()
        self.delta = self.X_cont[sorted_idx[2]].copy() if self.pop_size > 2 else self.alpha.copy()
        self.alpha_score = self.fitness[sorted_idx[0]]

    def _update_global_best(self):
        """Track global best solution (binary)."""
        alpha_bin = self._binarize(self.alpha)
        if (self.direction == "MAX" and self.alpha_score > self.best_value) or \
           (self.direction == "MIN" and self.alpha_score < self.best_value):
            self.best_value = self.alpha_score
            self.best_solution = alpha_bin.copy()
        self.best_history.append(self.best_value)

    def optimize(self):
        """Main optimization loop."""
        for t in range(self.max_iter):
            # Linearly decreasing coefficient a
            a = self.a_max - (self.a_max - self.a_min) * (t / (self.max_iter - 1 + 1e-12))

            for i in range(self.pop_size):
                X_new = np.zeros(self.dim)
                for leader in [self.alpha, self.beta, self.delta]:
                    r1, r2 = np.random.rand(2) # Simplify random generation
                    A = 2 * a * r1 - a
                    C = 2 * r2
                    D = np.abs(C * leader - self.X_cont[i])
                    X_new += (leader - A * D) # Accumulate the three estimated positions
                self.X_cont[i] = np.clip(X_new / 3, self.X_min, self.X_max) # Average and update

            # Map to binary once per iteration
            self.X_bin = self._binarize(self.X_cont)

            # Evaluate fitness
            self.fitness = np.array([self.problem_func(list(ind)) for ind in self.X_bin])

            # Update hierarchy and global best
            self._update_hierarchy()
            self._update_global_best()

        return self.best_value, self.best_history
