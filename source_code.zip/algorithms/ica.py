import numpy as np
import random
from utils.transfer_functions import TransferFunctions


class BinaryICA:
    """
    Binary Imperialist Competitive Algorithm (BICA)
    FE-controlled version: exactly pop_size evaluations per iteration.
    """

    def __init__(self, problem_func, dim, pop_size=30, n_imperialists=5,
                 max_iter=100, direction="MAX", seed=None,
                 assimilation_rate=0.3, revolution_rate=0.05,
                 transfer_function="sigmoid"):

        # Basic parameters
        self.problem_func = problem_func
        self.dim = dim
        self.pop_size = pop_size
        self.n_imperialists = n_imperialists
        self.max_iter = max_iter
        self.direction = direction.upper()
        self.assimilation_rate = assimilation_rate
        self.revolution_rate = revolution_rate
        self.transfer_function = transfer_function

        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)

        # Initialize evaluation (initial pop evaluated once)
        self.X_bin = (np.random.rand(pop_size, dim) >= 0.5).astype(int)
        self.fitness = np.array([self.problem_func(list(ind)) for ind in self.X_bin])
        # Continuous population (main representation)
        self.X_cont = np.random.rand(pop_size, dim)

        # Initialize empires (this sets imperialists, colonies, and their fitness arrays)
        self._form_empires()

        # IMPORTANT: initialize binarized imperialists/colonies so other methods can use them
        # This avoids AttributeError when _update_global_best() is called next.
        self.X_bin_imperialists = self._binarize(self.imperialists)
        self.X_bin_colonies = self._binarize(self.colonies)

        # Track best solution
        if self.direction == "MAX":
            self.best_value = -np.inf
        else:
            self.best_value = np.inf

        self.best_solution = None
        self.best_history = []

        # Initialize best using current imperialists (safe now)
        self._update_global_best()

    # ===============================================================
    #   Core operations
    # ===============================================================
    def _binarize(self, cont_positions):
        """Continuous → binary using the selected transfer function."""
        if self.transfer_function == "sigmoid":
            probs = TransferFunctions._sigmoid(cont_positions)
        elif self.transfer_function == "tanh":
            probs = TransferFunctions._tanh(cont_positions)
        elif self.transfer_function == "v3":
            probs = TransferFunctions._v3(cont_positions)
        else:
            raise ValueError(f"Unknown transfer function {self.transfer_function}")

        return (np.random.rand(*probs.shape) < probs).astype(int)

    def _form_empires(self):
        """Sort population and assign imperialists + colony ownership."""
        if self.direction == "MAX":
            idx = np.argsort(-self.fitness)
        else:
            idx = np.argsort(self.fitness)

        # split continuous and fitness arrays
        self.imperialists = self.X_cont[idx[:self.n_imperialists]].copy()
        self.imperialist_fitness = self.fitness[idx[:self.n_imperialists]].copy()

        self.colonies = self.X_cont[idx[self.n_imperialists:]].copy()
        self.colony_fitness = self.fitness[idx[self.n_imperialists:]].copy()

        # Assign colonies to imperialists proportionally to imperialist fitness magnitude
        strength = np.abs(self.imperialist_fitness)
        if np.sum(strength) == 0:
            strength = np.ones_like(strength)

        probs = strength / np.sum(strength)
        if len(self.colonies) > 0:
            self.colony_owner = np.random.choice(self.n_imperialists,
                                                 size=len(self.colonies),
                                                 p=probs)
        else:
            self.colony_owner = np.array([], dtype=int)

    # ===============================================================
    #   Algorithmic steps
    # ===============================================================
    def _assimilation(self):
        """Move colonies toward their assigned imperialists."""
        beta = 2.0
        for i in range(len(self.colonies)):
            if np.random.rand() < self.assimilation_rate:
                imp = self.imperialists[self.colony_owner[i]]
                R = np.random.rand(self.dim)
                self.colonies[i] += beta * R * (imp - self.colonies[i])

    def _revolution(self):
        """Randomly flip some continuous variables (bit flip after binarization)."""
        for i in range(len(self.colonies)):
            flip_mask = np.random.rand(self.dim) < self.revolution_rate
            self.colonies[i, flip_mask] = 1 - self.colonies[i, flip_mask]

    # ===============================================================
    #   FE-controlled evaluation
    # ===============================================================
    def _evaluate_all(self):
        """
        Evaluate EVERY individual exactly once.
        This ensures EXACTLY pop_size FE/iteration.
        """
        all_cont = np.vstack([self.imperialists, self.colonies]) if len(self.colonies) > 0 else self.imperialists.copy()
        all_bin = self._binarize(all_cont)

        all_fit = np.array([self.problem_func(list(x)) for x in all_bin])

        # Split
        self.imperialist_fitness = all_fit[:self.n_imperialists]
        self.colony_fitness = all_fit[self.n_imperialists:] if len(all_fit) > self.n_imperialists else np.array([])

        # Store binary representations
        self.X_bin_imperialists = all_bin[:self.n_imperialists]
        self.X_bin_colonies = all_bin[self.n_imperialists:] if len(all_bin) > self.n_imperialists else np.empty((0, self.dim), dtype=int)

    # ===============================================================
    #   Competition + Rebuilding empires
    # ===============================================================
    def _imperialist_competition(self):
        """Competition: weakest empire loses a colony to the strongest."""
        total_cost = np.copy(self.imperialist_fitness)

        # Add colony contribution
        for i in range(self.n_imperialists):
            mask = (self.colony_owner == i)
            if np.any(mask):
                avg = np.mean(self.colony_fitness[mask])
                total_cost[i] += 0.1 * avg

        # Determine strongest and weakest
        if self.direction == "MAX":
            strongest = np.argmax(total_cost)
            weakest = np.argmin(total_cost)
        else:
            strongest = np.argmin(total_cost)
            weakest = np.argmax(total_cost)

        # Weakest empire loses one colony to the strongest
        weak_mask = np.where(self.colony_owner == weakest)[0]
        if len(weak_mask) > 0:
            chosen = np.random.choice(weak_mask)
            self.colony_owner[chosen] = strongest

    # ===============================================================
    #   Global best tracking
    # ===============================================================
    def _update_global_best(self):
        """Pick best imperialist only (standard ICA convention)."""
        if self.imperialist_fitness.size == 0:
            return

        if self.direction == "MAX":
            idx = np.argmax(self.imperialist_fitness)
            best_val = self.imperialist_fitness[idx]
            if best_val > self.best_value:
                self.best_value = best_val
                self.best_solution = self.X_bin_imperialists[idx].copy()
        else:
            idx = np.argmin(self.imperialist_fitness)
            best_val = self.imperialist_fitness[idx]
            if best_val < self.best_value:
                self.best_value = best_val
                self.best_solution = self.X_bin_imperialists[idx].copy()

        self.best_history.append(self.best_value)

    # ===============================================================
    #   Optimization Loop (FE-controlled)
    # ===============================================================
    def optimize(self):
        """Main loop: EXACTLY pop_size FE per iteration."""
        for t in range(self.max_iter):

            # 1) Movement
            self._assimilation()
            self._revolution()

            # 2) Evaluate everyone (pop_size FE exactly)
            self._evaluate_all()

            # 3) Competition
            self._imperialist_competition()

            # 4) Track best
            self._update_global_best()

        return self.best_value, self.best_history
