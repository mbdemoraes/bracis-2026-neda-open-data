import numpy as np

class TestProblems:
    def __init__(self, dim=30, seed=None, problem=None):
        self.dim = dim  # problem dimension
        self.seed = seed  # can be NoneW
        if self.seed is not None:
            np.random.seed(self.seed)
        self.x_star = np.random.randint(0, 2, size=self.dim)
        self.profits = np.random.uniform(-5, 5, size=self.dim)
        self.problem = problem
    
    def bcbkp(self, x):
        return np.sum(np.multiply(x, self.profits))
    
    def quadratic_binary(self,x):
        return -np.sum((x - self.x_star)**2)
    
    def exp_binary(self,x, alpha=0.01):
        return np.exp(-alpha * np.sum((x - self.x_star)**2))
    
    def product_binary(self,x, beta=0.01):
        return -np.prod(1 + beta * np.abs(x - self.x_star))
    
    def onemax(self, x):
        return np.sum(x)
    
    def leading_ones(self, x):
        """
        Calculate the Leading Ones objective function.
        
        Parameters
        ----------
        x : list or np.ndarray
            Binary vector (contains only 0s and 1s).
        
        Returns
        -------
        int
            Number of consecutive 1s from the start.
        """
        x = np.asarray(x)
        count = 0
        for bit in x:
            if bit == 1:
                count += 1
            else:
                break
        return count
    
    
    def func(self, x):
        f = 0
        if self.problem=="BCBKP":
            f = self.bcbkp(x=x)
        elif self.problem=="Quadratic":
            f = self.quadratic_binary(x=x)
        elif self.problem=="Product":
            f = self.product_binary(x=x)
        elif self.problem=="Exp":
            f = self.exp_binary(x=x)
        elif self.problem=="OneMax":
            f = self.onemax(x=x)
        elif self.problem=="LeadingOnes":
            f = self.leading_ones(x=x)
        return f
        