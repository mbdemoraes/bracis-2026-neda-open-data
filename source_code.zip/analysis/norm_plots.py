import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# -------------------------------------------------------
# Load all CSV histories for a given pop_size
# -------------------------------------------------------
def load_csv_popsize(csv_path, pop_size):
    if not os.path.exists(csv_path):
        print(f"⚠️ File not found: {csv_path}")
        return None

    df = pd.read_csv(csv_path)

    if "pop_size" not in df.columns:
        print(f"⚠️ pop_size column missing: {csv_path}")
        return None

    df = df[df["pop_size"] == pop_size]

    if df.empty:
        print(f"⚠️ No entries with pop_size={pop_size} in {csv_path}")
        return None

    iter_cols = [c for c in df.columns if c.startswith("it")]

    if not iter_cols:
        print(f"⚠️ No iteration columns in: {csv_path}")
        return None

    # Mean convergence curve
    mean_curve = df[iter_cols].mean().values
    return mean_curve


# -------------------------------------------------------
# Plot a single convergence curve
# -------------------------------------------------------
def plot_curve_ax(ax, problem, dim, algorithms, pop_size,
                  base_dir="../results/test_problems"):
    for alg in algorithms:
        csv_path = f"{base_dir}/{problem}/n{dim}/{alg}.csv"

        mean_curve = load_csv_popsize(csv_path, pop_size)
        if mean_curve is None:
            continue

        iterations = np.arange(1, len(mean_curve) + 1)
        fe_axis = iterations * pop_size  # <-- convert to function evaluations

        ax.plot(fe_axis, mean_curve, label=alg, linewidth=3, color=colors.get(alg, None))
        ax.set_xlabel("Function evaluations")

    ax.set_title(f"{problem_names[problem]}", fontsize=16)
    #ax.set_xlabel("Iteration")
    ax.set_ylabel("Mean best objective")
    #ax.grid(True, linestyle="--", alpha=0.5)
    ax.legend(
        loc="center left",
        bbox_to_anchor=(1.02, 0.5)
    )


# -------------------------------------------------------
# Main: create a grid of subplots
# -------------------------------------------------------

benchmarks = [
    "BCBKP",
    "OneMax",
    "LeadingOnes",
    "Quadratic",
    "Product",
    "Exp"
]

problem_names = {
    "OneMax": "OM",
    "BCBKP": "UK",
    "Product": "PB",
    "Exp": "EB",
    "Quadratic": "QB",
    "LeadingOnes": "LO"
}

algorithms = ["GWO", "ICA", "IDLHC", "REDA", "NEDA"]
pop_size = 10
dim = 25
colors = {
    "NEDA": "red",
    "IDLHC": "green",
    "ICA": "orange",
    "GWO": "purple",
    "REDA": "brown",
}

plt.rcParams.update({'font.size': 16})
fig, axes = plt.subplots(3, 2, figsize=(14, 12))

axes = axes.flatten()

for ax, problem in zip(axes, benchmarks):
    plot_curve_ax(
        ax=ax,
        problem=problem,
        dim=dim,
        algorithms=algorithms,
        pop_size=pop_size,
        base_dir="../results/test_problems"
    )

fig.align_ylabels(axes)
plt.tight_layout()
plt.savefig("../figures/conv.pdf", dpi=300)
plt.show()
