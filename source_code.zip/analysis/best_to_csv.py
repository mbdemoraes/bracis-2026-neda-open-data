import os
import csv
import numpy as np
from collections import defaultdict
import pandas as pd

# ------------------------------------------------------------
# Load CSV (same as your current function)
# ------------------------------------------------------------
def load_algorithm_csv(csv_path):
    variants = defaultdict(list)
    param_names = None

    with open(csv_path, newline='') as f:
        reader = csv.reader(f)
        header = next(reader)

        it_start = [i for i, h in enumerate(header) if h.startswith("it")][0]

        param_names = header[:it_start - 1]
        it_names = header[it_start:]

        for row in reader:
            params = tuple(row[:len(param_names)])
            run_id = int(row[len(param_names)])

            history = np.array(list(map(float, row[it_start:])))
            variants[params].append((run_id, history))

    return param_names, variants


# ------------------------------------------------------------
# Pick best variant based on mean final value
# ------------------------------------------------------------
def find_best_variant(variants):
    best_key = None
    best_mean = -np.inf

    for params, runlist in variants.items():
        histories = np.array([h for (_, h) in runlist], dtype=float)
        avg_final = histories[:, -1].mean()
        if avg_final > best_mean:
            best_mean = avg_final
            best_key = params

    return best_key


# ------------------------------------------------------------
# Extract final values per run of best variant
# ------------------------------------------------------------
def extract_final_values(variants, best_params):
    """returns dict: run → final_value"""
    run_dict = {}
    for run_id, hist in variants[best_params]:
        run_dict[run_id] = hist[-1]
    return run_dict


# ------------------------------------------------------------
# Main CSV generator
# ------------------------------------------------------------
def generate_summary_csv(
        base_dir="../results/test_problems",
        problems=["OneMax", "LeadingOnes", "BCBKP", "Quadratic", "Product", "Exp"],
        algorithms=["GWO", "ICA", "IDLHC", "REDA", "NEDA"],
        dims=[25]
    ):
    problem_names = {
        "OneMax": "OM",
        "BCBKP": "UK",
        "Product": "PB",
        "Exp": "EB",
        "Quadratic": "QB",
        "LeadingOnes": "LO"
    }
    output_rows = []

    for problem in problems:
        for n in dims:
            problem_dir = f"{base_dir}/{problem}/n{n}"

            # dict: algorithm → run→value
            alg_run_tables = {}

            for alg in algorithms:
                csv_path = f"{problem_dir}/{alg}.csv"

                if not os.path.exists(csv_path):
                    print(f"[WARN] Missing CSV for {alg}: {csv_path}")
                    continue

                param_names, variants = load_algorithm_csv(csv_path)

                if len(variants) == 0:
                    print(f"[WARN] Empty CSV for {alg}: {csv_path}")
                    continue

                best_params = find_best_variant(variants)
                run_dict = extract_final_values(variants, best_params)

                alg_run_tables[alg.lower()] = run_dict  # keys in lowercase to match your example

            # Find all run IDs (union)
            all_runs = sorted(set.union(*[set(d.keys()) for d in alg_run_tables.values()]))

            # Build final rows
            for run_id in all_runs:
                row = {"run": run_id}

                for alg in algorithms:
                    key = alg.lower()
                    if key in alg_run_tables and run_id in alg_run_tables[key]:
                        row[key] = alg_run_tables[key][run_id]
                    else:
                        row[key] = np.nan   # missing run

                row["n"] = n
                row["problem"] = problem_names[problem]

                output_rows.append(row)

    # Convert to DataFrame
    df = pd.DataFrame(output_rows)

    # Save CSV
    out_path = "summary_best_variants.csv"
    df.to_csv(out_path, index=False)

    print(f"Saved: {out_path}")
    return df


# ------------------------------------------------------------
# Run generator
# ------------------------------------------------------------
df = generate_summary_csv()

