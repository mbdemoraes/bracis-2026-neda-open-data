import os
import csv
import numpy as np
import pandas as pd
from collections import defaultdict

# ============================================================
# SETTINGS
# ============================================================
problems = ["OneMax", "LeadingOnes", "BCBKP", "Product", "Exp", "Quadratic"]
dims = [25, 50, 75, 100]
methods = ["GWO", "ICA", "IDLHC", "REDA", "NEDA"]

# ============================================================
# HELPERS FOR LATEX TABLE
# ============================================================
def fmt(x):
    if x is None or pd.isna(x):
        return ""
    if abs(x) >= 1e4:
        sci = f"{x:.1e}"
        base, exp = sci.split("e")
        exp = int(exp)
        return f"{base} \\times 10^{{{exp}}}"
    else:
        return f"{x:.1f}"

def bold_best_mean(values, maximize=True):
    clean = [v if v is not None else None for v in values]
    numeric_list = [float(v) for v in clean if v is not None]
    if not numeric_list:
        return [False] * len(clean)
    numeric = np.array(numeric_list)
    best = numeric.max() if maximize else numeric.min()
    best_mask_numeric = np.isclose(numeric, best, rtol=1e-6, atol=1e-9)
    out_mask = []
    j = 0
    for v in clean:
        if v is None:
            out_mask.append(False)
        else:
            out_mask.append(bool(best_mask_numeric[j]))
            j += 1
    return out_mask

def fmt_mean_std(mean, std):
    if mean is None:
        return ""
    return f"${fmt(mean)} \\pm {fmt(std)}$"

# ============================================================
# HELPERS FOR BEST VARIANT EXTRACTION
# ============================================================
def load_algorithm_csv(csv_path):
    """Load CSV and return all variants grouped by parameter tuples"""
    variants = defaultdict(list)
    with open(csv_path, newline='') as f:
        reader = csv.reader(f)
        header = next(reader)
        it_start = [i for i, h in enumerate(header) if h.startswith("it")][0]
        param_names = header[:it_start - 1]

        for row in reader:
            params = tuple(row[:len(param_names)])
            run_id = int(row[len(param_names)])
            history = np.array(list(map(float, row[it_start:])))
            variants[params].append((run_id, history))
    return param_names, variants

def find_best_variant(variants):
    """Return the best parameter tuple based on mean final value"""
    best_key = None
    best_mean = -np.inf
    for params, runlist in variants.items():
        histories = np.array([h for (_, h) in runlist], dtype=float)
        avg_final = histories[:, -1].mean()
        if avg_final > best_mean:
            best_mean = avg_final
            best_key = params
    return best_key

def extract_final_values(variants, best_params):
    """Return dict: run_id -> final_value"""
    return {run_id: hist[-1] for run_id, hist in variants[best_params]}

# ============================================================
# LOAD ALL RESULTS (for table and CSV)
# ============================================================
results = {}       # For latex table (mean ± std)
summary_rows = []  # For CSV output

for problem in problems:
    results[problem] = {}
    for dim in dims:
        results[problem][dim] = {}
        base = f"..\\results\\test_problems\\{problem}\\n{dim}"

        alg_run_tables = {}  # temp storage for summary CSV

        for m in methods:
            path = os.path.join(base, f"{m}.csv")
            if not os.path.isfile(path):
                results[problem][dim][m] = None
                continue

            # load CSV and best variant
            param_names, variants = load_algorithm_csv(path)
            best_params = find_best_variant(variants)
            run_dict = extract_final_values(variants, best_params)
            alg_run_tables[m] = run_dict

            # save statistics for latex table
            finals = np.array(list(run_dict.values()))
            results[problem][dim][m] = {
                "Mean": float(np.mean(finals)),
                "Std": float(np.std(finals))
            }

        # build summary rows for CSV (one row per run)
        if alg_run_tables:
            all_runs = sorted(set().union(*[set(d.keys()) for d in alg_run_tables.values()]))
            for run_id in all_runs:
                row = {"run": run_id, "n": dim, "problem": problem}
                for m in methods:
                    row[m] = alg_run_tables.get(m, {}).get(run_id, np.nan)
                summary_rows.append(row)

# ============================================================
# SAVE SUMMARY CSV
# ============================================================
summary_df = pd.DataFrame(summary_rows)
summary_df.to_csv("summary_best_variants.csv", index=False)
print("Saved summary_best_variants.csv")

# ============================================================
# PRINT LATEX TABLE
# ============================================================
def print_normal_table(subset_problems, caption):
    print("\\begin{table}[!t]")
    print("\\centering")
    print("\\caption{" + caption + "}")
    print("\\begin{tabular}{c c " + "c " * len(methods) + "}")
    print("\\hline")

    header = "Problem & Dim "
    for m in methods:
        header += f"& {m} "
    print(header + "\\\\")
    print("\\hline")

    for problem in subset_problems:
        first_problem_row = True
        for dim in dims:
            means, stds = [], []
            for m in methods:
                stats = results[problem][dim][m]
                if stats is None:
                    means.append(None)
                    stds.append(None)
                else:
                    means.append(stats.get("Mean"))
                    stds.append(stats.get("Std"))
            bold_mask = bold_best_mean(means, maximize=True)

            row_vals = []
            for is_bold, mean, std in zip(bold_mask, means, stds):
                if mean is None:
                    row_vals.append("")
                    continue
                numeric = fmt(mean)
                if is_bold:
                    bold_numeric = f"\\textbf{{{numeric}}}"
                    row_vals.append(f"${bold_numeric} \\pm {fmt(std)}$")
                else:
                    row_vals.append(fmt_mean_std(mean, std))

            row = f"\\multirow{{{len(dims)}}}{{*}}{{{problem_names[problem]}}} & " if first_problem_row else "& "
            first_problem_row = False
            row += f"{dim} " + " ".join(f"& {v} " for v in row_vals)
            print(row + "\\\\")

        print("\\hline")
    print("\\end{tabular}")
    print("\\end{table}")
    print()


problem_names = {
    "OneMax": "OM",
    "BCBKP": "UK",
    "Product": "PB",
    "Exp": "EB",
    "Quadratic": "QB",
    "LeadingOnes": "LO"
}
# ============================================================
# RUN LATEX TABLE PRINTING
# ============================================================
print_normal_table(
    ["OneMax", "LeadingOnes", "BCBKP", "Product", "Exp", "Quadratic"],
    "Comparison Results (Mean $\\pm$ Std)"
)
