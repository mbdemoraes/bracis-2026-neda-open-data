import pandas as pd
import numpy as np
from scipy.stats import friedmanchisquare, wilcoxon

# ===============================
# SETTINGS
# ===============================
csv_path = "summary_best_variants.csv"
algorithms = ["GWO", "ICA", "IDLHC", "REDA", "NEDA"]

# ===============================
# LOAD CSV
# ===============================
df = pd.read_csv(csv_path)
print(df.head())

# ===============================
# FUNCTION TO RUN STATISTICAL TESTS
# ===============================
def analyze_significance_wilcoxon(df, algorithms, alpha=0.05):
    problems = df['problem'].unique()
    dims = df['n'].unique()

    for problem in problems:
        for n in dims:
            subset = df[(df['problem'] == problem) & (df['n'] == n)]

            # Extract data matrix (rows=runs, cols=algorithms)
            data = np.array([subset[alg].values for alg in algorithms]).T  # shape: (runs, algorithms)

            if data.shape[0] < 2:
                print(f"\nNot enough runs for {problem} n={n}, skipping")
                continue

            # Friedman test (overall check)
            stat, p = friedmanchisquare(*[data[:, i] for i in range(data.shape[1])])
            print(f"\nProblem: {problem}, n={n}")
            print(f"Friedman test: chi2={stat:.4f}, p={p:.4e}")

            # Pairwise Wilcoxon: NEDA vs others
            print("Wilcoxon signed-rank test: NEDA vs other methods")
            neda_idx = algorithms.index("NEDA")
            for i, alg in enumerate(algorithms):
                if alg == "NEDA":
                    continue

                try:
                    stat_w, p_w = wilcoxon(data[:, neda_idx], data[:, i])
                    sig = "SIGNIFICANT" if p_w < alpha else "Not significant"
                    print(f"- NEDA vs {alg}: W={stat_w:.2f}, p={p_w:.3e} → {sig}")
                except ValueError as e:
                    # This happens if all differences are zero
                    print(f"- NEDA vs {alg}: cannot compute Wilcoxon (all differences zero)")

# ===============================
# RUN ANALYSIS
# ===============================
analyze_significance_wilcoxon(df, algorithms)
