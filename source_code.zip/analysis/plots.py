import os
import csv
import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict
import matplotlib.gridspec as gridspec

# ------------------------------------------------------------
# Convert per-iteration history to per-function-evaluations curve
# ------------------------------------------------------------
def history_to_fe_curve(history, pop_size, max_eval):
    curve = np.zeros(max_eval + 1)
    T = len(history)

    for it in range(T):
        fe = (it + 1) * pop_size
        fe = min(fe, max_eval)

        if it == 0:
            curve[pop_size:fe + 1] = history[it]
        else:
            prev_fe = it * pop_size
            curve[prev_fe:fe + 1] = history[it]

    curve[fe:] = history[-1]
    return curve


# ------------------------------------------------------------
# Load CSV
# ------------------------------------------------------------
def load_algorithm_csv(csv_path):
    variants = defaultdict(list)
    param_names = None

    with open(csv_path, newline='') as f:
        reader = csv.reader(f)
        header = next(reader)

        it_start = [i for i, h in enumerate(header) if h.startswith("it")][0]

        param_names = header[:it_start - 1]
        it_names = header[it_start:]

        for row in reader:
            params = tuple(row[:len(param_names)])
            run = int(row[len(param_names)])
            history = np.array(list(map(float, row[it_start:])))
            variants[params].append(history)

    return param_names, variants


# ------------------------------------------------------------
# Pick best variant based on mean final value
# ------------------------------------------------------------
def find_best_variant(variants):
    best_key = None
    best_mean = -np.inf

    for params, histories in variants.items():
        histories = np.array(histories, dtype=float)
        avg_final = histories[:, -1].mean()

        if avg_final > best_mean:
            best_mean = avg_final
            best_key = params

    return best_key


# ------------------------------------------------------------
# Colors for algorithms
# ------------------------------------------------------------
colors = {
    "NEDA": "red",
    "EDA": "grey",
    "BAT": "blue",
    "IDLHC": "green",
    "ICA": "orange",
    "GWO": "purple",
    "REDA": "brown",
    "REDALS": "magenta",
}

markers = {
    "NEDA": "s",
    "BAT": "d",
    "EDA": "v",
    "IDLHC": "^",
    "ICA": "v",
    "GWO": "*",
    "REDA": "o",
    "REDALS": "x",
}

problem_names = {
    "OneMax": "OM",
    "BCBKP": "UK",
    "Product": "PB",
    "Exp": "EB",
    "Quadratic": "QB",
    "LeadingOnes": "LO"
}


# ------------------------------------------------------------
# Plot convergence in a *specific axis*
# ------------------------------------------------------------
def plot_best_convergence_ax(ax, problem, dim, algorithms,
                             base_dir="../results/test_problems",
                             max_eval=200):

    for alg in algorithms:
        csv_path = f"{base_dir}/{problem}/n{dim}/{alg}.csv"

        if not os.path.exists(csv_path):
            print(f"Skipping {alg}: no CSV found at {csv_path}")
            continue

        param_names, variants = load_algorithm_csv(csv_path)

        if len(variants) == 0:
            print(f"Skipping {alg}: empty CSV.")
            continue

        best_params = find_best_variant(variants)
        histories = np.array(variants[best_params], dtype=float)

        if "pop_size" not in param_names:
            print(f"Skipping {alg}: no pop_size column.")
            continue

        pop_idx = param_names.index("pop_size")
        pop_size = int(best_params[pop_idx])

        fe_histories = np.array([
            history_to_fe_curve(h, pop_size, max_eval)
            for h in histories
        ])

        mean_curve = fe_histories.mean(axis=0)

        start = pop_size
        x = np.arange(start, len(mean_curve))
        y = mean_curve[start:]

        ax.plot(
            x,
            y,
            label=alg,
            linewidth=4,
            color=colors.get(alg, None),
        )

    ax.set_title(f"{problem_names[problem]}")
    ax.set_xlabel("Function evaluations")
    ax.set_ylabel("Average best $f^*$")
    ax.set_xlim(0, max_eval)
    ax.legend(
        loc="center left",
        bbox_to_anchor=(1.02, 0.5)
    )


# ------------------------------------------------------------
# Main — one figure with 6 subplots (3×2)
# ------------------------------------------------------------
benchmarks = [
    "OneMax",
    "LeadingOnes",
    "BCBKP",
    "Quadratic",
    "Product",
    "Exp"
]

algorithms = ["GWO", "ICA", "IDLHC", "REDA", "NEDA"]

plt.rcParams.update({'font.size': 18})
fig = plt.figure(figsize=(14,12), constrained_layout=False)
gs = gridspec.GridSpec(3, 2, figure=fig)

axes = [fig.add_subplot(gs[i, j]) for i in range(3) for j in range(2)]

counter=0
for ax, problem in zip(axes, benchmarks):
    plot_best_convergence_ax(
        ax=ax,
        problem=problem,
        dim=25,
        algorithms=algorithms,
        max_eval=200
    )


fig.tight_layout(rect=[0, 0, 0.92, 1])
plt.savefig("../figures/conv.pdf", dpi=300)
plt.show()
