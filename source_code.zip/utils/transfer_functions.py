import numpy as np
from scipy.special import expit

class TransferFunctions:

    @staticmethod
    def _sigmoid(x):
        """Sigmoid transformation for binary conversion."""
        return np.abs(expit(x))
    
    @staticmethod
    def _tanh(x):
        """Tanh transformation for binary conversion."""
        return np.abs(np.tanh(x))

    @staticmethod
    def _v3(x):
        """V3 transformation for binary conversion"""
        return np.abs(x / np.sqrt(1 + x**2))
    