import sys
import os
import numpy as np
sys.path.append(os.path.abspath(".."))

import algorithms.idlhc as idlhc_module
import algorithms.neda as idlhc_hybrid_module
import algorithms.gwo as gwo_module
import algorithms.ica as ica_module
import algorithms.redals as redals_module

from problems.test_problems import TestProblems
from itertools import product
import multiprocessing as mp
import json, csv, math
from tqdm import tqdm


# ===========================
# CONFIG
# ===========================
config = {
    "n_runs": 31,
    "max_eval": 200,
    "algorithms": ["ICA", "GWO", "REDA", "IDLHC", "NEDA"],
    "problems": ["OneMax", "LeadingOnes", "BCBKP", "Exp", "Quadratic", "Product"],
    "dimensions": [25, 50, 75, 100]
}


# -----------------------------
# PARAM GRID
# -----------------------------
param_grid = {
    "IDLHC": {
        "pop_size": [5,10,20,25],
        "num_pdf": [2,3,4,5],
        "num_cut_pdf": [0.1,0.2,0.3]
    },
    "NEDA": {
        "pop_size": [5,10,20,25],
        "num_pdf": [2,3,4,5],
        "noise_dev": [0.01,0.05,0.10,0.20]
    },

    "GWO": {
        "pop_size": [5,10,20,25],
        "transfer_function": ["sigmoid", "tanh", "v3"],
        "X_max": [1],
        "X_min": [0]
    },
    "REDA": {
        "pop_size": [5,10,20,25],
        "num_pdf": [2,3,4,5],
        "type": ["REDA"],
        "f_factor": [2]
    },
    "ICA": {
        "pop_size": [5,10,20,25],
        "n_imperialists": [2,3,4,5],
        "assimilation_rate": [0.2, 0.4, 0.6],
        "revolution_rate": [0.01, 0.05, 0.1],
        "transfer_function": ["sigmoid", "tanh", "v3"]
    }
}


# ===========================
# PARAM COMBINATION GENERATOR
# ===========================
def param_combinations(param_dict):
    keys = list(param_dict.keys())
    values = list(param_dict.values())
    for combo in product(*values):
        yield dict(zip(keys, combo))


# ===========================
# WORKER FUNCTION
# ===========================
def run_single_execution(args):
    (alg_name, params, problem_name, dim, seed, max_iter) = args

    problem = TestProblems(seed=dim, dim=dim, problem=problem_name)

    if alg_name == "IDLHC":
        alg = idlhc_module.IDLHC_SelfContained(
            problem.func, dim=dim, variables=[0,1],
            max_iter=max_iter, seed=seed, **params)

    elif alg_name == "NEDA":
        alg = idlhc_hybrid_module.IDLHC_BB_Hybrid(
            problem.func, dim=dim, variables=[0,1],
            max_iter=max_iter, seed=seed, **params)

    elif alg_name == "ICA":
        alg = ica_module.BinaryICA(
            problem.func, dim=dim, max_iter=max_iter,
            seed=seed, **params)

    elif alg_name == "GWO":
        alg = gwo_module.BinaryGWO(
            problem.func, dim=dim, max_iter=max_iter,
            seed=seed, **params)

    elif alg_name == "REDA":
        alg = redals_module.REDALS(
            problem.func, dim=dim, variables=[0,1],
            max_iter=max_iter, seed=seed, **params)

    best_score, best_history = alg.optimize()
    return (alg_name, params, problem_name, dim, seed, best_score, best_history)



# =====================================================================
# MAIN BLOCK — REQUIRED FOR WINDOWS
# =====================================================================
if __name__ == "__main__":
    mp.freeze_support()

    # ===========================
    # BUILD JOB LIST
    # ===========================
    jobs = []
    variant_params = {}

    for problem_name in config["problems"]:
        for dim in config["dimensions"]:
            for alg_name in config["algorithms"]:

                combos = list(param_combinations(param_grid.get(alg_name, {}))) or [{}]

                for combo_id, params in enumerate(combos):
                    variant_key = f"{alg_name}_v{combo_id}"
                    variant_params[variant_key] = params.copy()

                    pop_size_value = params.get("pop_size", 1)
                    max_iter = int(config["max_eval"] / pop_size_value) - 1

                    for seed in range(config["n_runs"]):
                        jobs.append((alg_name, params, problem_name, dim, seed, max_iter))


    # ===========================
    # RUN PARALLEL WITH PROGRESS BAR
    # ===========================
    print(f"Launching {len(jobs)} parallel executions...")

    with mp.Pool(mp.cpu_count()) as pool:
        results_raw = list(
            tqdm(
                pool.imap_unordered(run_single_execution, jobs),
                total=len(jobs),
                desc="Running",
                smoothing=0.1
            )
        )

    print("All parallel executions finished.")


    # ===========================
    # ORGANIZE RESULTS
    # ===========================
    results = {}
    results_history = {}

    for alg_name, params, problem_name, dim, seed, best_score, best_history in results_raw:

        variant_key = None
        for k, v in variant_params.items():
            if k.startswith(alg_name) and v == params:
                variant_key = k
                break

        results.setdefault(problem_name, {}).setdefault(dim, {}).setdefault(variant_key, [])
        results_history.setdefault(problem_name, {}).setdefault(dim, {}).setdefault(variant_key, [])

        results[problem_name][dim][variant_key].append(best_score)
        results_history[problem_name][dim][variant_key].append(best_history)


    # ===========================
    # REMOVE OLD FILES
    # ===========================
    for problem_name in config["problems"]:
        for dim in config["dimensions"]:
            for alg_name in config["algorithms"]:
                dir_path = f"results/test_problems/{problem_name}/n{dim}/"
                if not os.path.exists(dir_path):
                    continue
                for file in os.listdir(dir_path):
                    if file.endswith(".csv") and alg_name in file:
                        os.remove(os.path.join(dir_path, file))

    # ===========================
    # WRITE NEW CSV FILES
    # ===========================
    for problem_name in config["problems"]:
        for dim in config["dimensions"]:
            for variant_key, runs in results[problem_name][dim].items():

                params = variant_params[variant_key]
                alg_name = variant_key.split("_")[0]

                dir_path = f"results/test_problems/{problem_name}/n{dim}/"
                os.makedirs(dir_path, exist_ok=True)
                csv_path = f"{dir_path}/{alg_name}.csv"

                history_list = results_history[problem_name][dim][variant_key]
                max_iters = max(len(h) for h in history_list)

                header = list(params.keys()) + ["run"] + [f"it{i+1}" for i in range(max_iters)]
                write_header = not os.path.exists(csv_path)

                with open(csv_path, mode="a", newline="") as f:
                    writer = csv.writer(f)

                    if write_header:
                        writer.writerow(header)

                    for run_idx, hist in enumerate(history_list, start=1):
                        if len(hist) < max_iters:
                            hist = hist + [hist[-1]] * (max_iters - len(hist))
                        writer.writerow(list(params.values()) + [run_idx] + list(hist))
